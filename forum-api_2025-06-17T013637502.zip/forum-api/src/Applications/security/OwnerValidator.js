class OwnerValidator {
  async validateOwner(credentialId, ownerId, entityType) {
    throw new Error("OWNER_VALIDATOR.METHOD_NOT_IMPLEMENTED");
  }
}

module.exports = OwnerValidator;
